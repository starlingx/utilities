#!/bin/bash
docker system prune
docker-compose up -d