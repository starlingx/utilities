#!/bin/bash
docker tag docker_app:latest nchen1windriver/collect:demo
docker push nchen1windriver/collect:demo